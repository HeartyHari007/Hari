<!DOCTYPE HTML>
<html lang="en">
<head>
    <?php 
    session_start();
    include '../connect.php';
    $result = ORM::for_table("site_settings")->find_array(1);
    ?>
    <?php foreach ($result as $res):?> 
    <title><?php echo $res['site_name'];?> :: Login Page </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="<?php echo $res['site_keyword'];?>" />
    <?php endforeach;?>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
    .main-content {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        background: #f5f5f5;
    }
    .form-container {
        background: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    .title1 {
        font-size: 24px;
        margin-bottom: 20px;
    }
    .btn-custom {
        background-color: #007bff;
        color: #fff;
    }
    .btn-custom:hover {
        background-color: #0056b3;
    }
    .text-custom {
        color: #007bff;
    }
    </style>
</head> 
<body>
<div class="main-content">
    <div class="container">
        <div class="row justify-content-center">
            <!-- Login Form -->
            <div class="col-md-6 col-lg-4 form-container" id="login">
                <h2 class="title1" style="text-align:center">Login</h2>
                <div class="widget-shadow">
                    <div class="login-body">
                        <form action="process_login.php" method="post">
                            <div class="form-group">
                                <input type="text" class="form-control" name="username" placeholder="Enter Your Email or Mobile No" required>
                            </div>
                            <div class="form-group">
                                <input type="password" name="password" class="form-control" placeholder="Password" required>
                            </div>
                            <button type="submit" class="btn btn-warning btn-block">Sign In</button>
                            <a class="d-block text-center mt-2 text-custom" onclick="reg();" style="cursor:pointer">New User? Create An Account</a>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Registration Form -->
            <div class="col-md-6 col-lg-4 form-container" id="reg" style="display: none;">
                <h2 class="title1" style="text-align:center">Create An Account</h2>
                <div class="widget-shadow">
                    <div class="login-body">
                        <form action="reg.php" method="post">
                            <div class="form-group">
                                <input type="text" class="form-control" name="name" placeholder="Enter Your Name" required>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="email" placeholder="Enter Your Email" required>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="mobileno" placeholder="Enter Your Mobile" required>
                            </div>
                            <div class="form-group">
                                <input type="password" name="password" class="form-control" placeholder="Password" required>
                            </div>
                            <button type="submit" class="btn btn-warning btn-block">Create Account</button>
                            <a class="d-block text-center mt-2 text-custom" onclick="login();" style="cursor:pointer">Go to Login</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- jQuery and Bootstrap Bundle with Popper -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
function reg() {
    document.getElementById("reg").style.display = "block";
    document.getElementById("login").style.display = "none";
}

function login() {
    document.getElementById("reg").style.display = "none";
    document.getElementById("login").style.display = "block";
}
</script>
</body>
</html>
